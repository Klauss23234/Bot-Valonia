module.exports = {
  token: 'MTM5NzU3MTY3NTg3MjAzNDkzOQ.GPA8Ef.qiHk6kkA9EkIu8FddxatpxdPj3pP3mPhHA4K94',
  prefix: '!',
  status: 'online',
  activity: 'Owner Klauss',
  channel_id: '1379153956852469951',
  supportRoleId: '1398003064941711431',
  categoryId: '1379172425790521504'  // pas de virgule ici car c’est la dernière ligne
};

